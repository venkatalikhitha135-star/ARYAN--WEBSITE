import { X, ExternalLink, Code, Palette, Zap, Check } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface CompanyPortfolioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CompanyPortfolioModal({ isOpen, onClose }: CompanyPortfolioModalProps) {
  if (!isOpen) return null;

  const projects = [
    {
      title: "TechVista Solutions",
      category: "Business Website",
      description: "Modern corporate website for a technology consulting firm with service showcase and client testimonials.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      technologies: ["React", "Tailwind CSS", "Framer Motion"],
      features: ["Responsive Design", "Contact Forms", "Blog Integration", "SEO Optimized"]
    },
    {
      title: "Sarah Martinez Portfolio",
      category: "Portfolio Website",
      description: "Creative portfolio website for a professional photographer showcasing stunning photography work.",
      image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      technologies: ["Next.js", "TypeScript", "CSS Grid"],
      features: ["Image Gallery", "Lightbox", "Smooth Scrolling", "Mobile First"]
    },
    {
      title: "FreshMart Online",
      category: "E-commerce",
      description: "Full-featured e-commerce platform for organic grocery delivery with real-time inventory management.",
      image: "https://images.unsplash.com/photo-1557821552-17105176677c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      technologies: ["React", "Node.js", "Stripe", "MongoDB"],
      features: ["Shopping Cart", "Payment Gateway", "Order Tracking", "Admin Dashboard"]
    },
    {
      title: "FitLife Coaching",
      category: "Personal Brand",
      description: "Personal brand website for a fitness coach with booking system and workout plan showcase.",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      technologies: ["React", "Tailwind CSS", "Calendar API"],
      features: ["Appointment Booking", "Video Tutorials", "Client Portal", "Progress Tracking"]
    },
    {
      title: "Urban Real Estate",
      category: "Business Website",
      description: "Premium real estate website with property listings, virtual tours, and lead generation.",
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      technologies: ["React", "Google Maps API", "Firebase"],
      features: ["Property Search", "Virtual Tours", "Lead Forms", "Map Integration"]
    },
    {
      title: "StyleHub Boutique",
      category: "E-commerce",
      description: "Fashion e-commerce store with size guides, wishlist functionality, and style recommendations.",
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      technologies: ["React", "Redux", "Stripe", "Tailwind CSS"],
      features: ["Product Filters", "Wishlist", "Size Guide", "Quick View"]
    }
  ];

  const stats = [
    { number: "20+", label: "Projects Completed" },
    { number: "100%", label: "Client Satisfaction" },
    { number: "2-3 Weeks", label: "Average Delivery" },
    { number: "24/7", label: "Support Available" }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/90 backdrop-blur-sm"
        onClick={onClose}
      ></div>
      
      {/* Modal */}
      <div className="relative min-h-screen flex items-start justify-center p-4 py-8">
        <div className="relative bg-gradient-to-b from-[#1a0d2e] to-[#0D0D0D] border border-[#7B2CBF]/30 rounded-2xl w-full max-w-6xl shadow-2xl shadow-[#7B2CBF]/20">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-gray-400 hover:text-white transition-colors z-10 bg-[#0D0D0D]/80 rounded-full p-2"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Header */}
          <div className="text-center px-8 pt-12 pb-8 border-b border-[#7B2CBF]/20">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Our{" "}
              <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
                Portfolio
              </span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] mx-auto mb-6"></div>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Explore our recent projects showcasing custom websites built for clients across various industries
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 px-8 py-8 border-b border-[#7B2CBF]/20">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent mb-2">
                  {stat.number}
                </div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="px-8 py-8">
            <div className="grid md:grid-cols-2 gap-8">
              {projects.map((project, index) => (
                <div
                  key={index}
                  className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl overflow-hidden hover:border-[#FF7A00]/50 transition-all hover:shadow-xl hover:shadow-[#7B2CBF]/20 group"
                >
                  {/* Image */}
                  <div className="relative h-56 overflow-hidden">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-transparent"></div>
                    <div className="absolute top-4 right-4">
                      <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white text-xs px-3 py-1 rounded-full">
                        {project.category}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
                    <p className="text-gray-400 mb-4 text-sm">{project.description}</p>

                    {/* Technologies */}
                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Code className="w-4 h-4 text-[#FF7A00]" />
                        <span className="text-sm text-gray-300 font-semibold">Technologies:</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech, i) => (
                          <span key={i} className="text-xs bg-[#7B2CBF]/20 text-[#FF7A00] px-2 py-1 rounded">
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Features */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="w-4 h-4 text-[#7B2CBF]" />
                        <span className="text-sm text-gray-300 font-semibold">Key Features:</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {project.features.map((feature, i) => (
                          <div key={i} className="flex items-center gap-1">
                            <Check className="w-3 h-3 text-[#FF7A00] flex-shrink-0" />
                            <span className="text-xs text-gray-400">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer CTA */}
          <div className="px-8 py-8 bg-gradient-to-r from-[#7B2CBF]/10 to-[#FF7A00]/10 border-t border-[#7B2CBF]/20 text-center rounded-b-2xl">
            <h3 className="text-2xl font-bold text-white mb-4">
              Ready to Start Your Project?
            </h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Join our growing list of satisfied clients. Let's build something amazing together!
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <a 
                href="#contact"
                onClick={onClose}
                className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white px-8 py-3 rounded-full hover:shadow-xl hover:shadow-[#7B2CBF]/50 transition-all inline-flex items-center gap-2 group"
              >
                Get Started Now
                <ExternalLink className="w-4 h-4 group-hover:scale-110 transition-transform" />
              </a>
              <button
                onClick={onClose}
                className="border-2 border-[#7B2CBF] text-white px-8 py-3 rounded-full hover:bg-[#7B2CBF]/10 transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}