import logoImage from "figma:asset/260b40a79ea63a067ec9e4d5000df200a972bfed.png";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src={logoImage} 
        alt="Aryan Innovations Logo" 
        className="h-16 w-auto object-contain"
      />
    </div>
  );
}