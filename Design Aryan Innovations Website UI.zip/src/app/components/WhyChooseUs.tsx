import { Palette, Smartphone, DollarSign, Zap, Shield, HeadphonesIcon } from "lucide-react";
import { useState } from "react";
import { FeatureDetailModal } from "./FeatureDetailModal";

export function WhyChooseUs() {
  const [selectedFeature, setSelectedFeature] = useState<any>(null);

  const features = [
    {
      icon: Palette,
      title: "Custom Design",
      description: "Tailored designs based on your unique client requirements",
      details: [
        "Unique visual identity crafted specifically for your brand",
        "Custom color schemes, typography, and visual elements",
        "Personalized layout and structure based on your business goals",
        "Integration of your brand guidelines and existing assets",
        "Collaborative design process with unlimited revisions",
        "Original graphics and visual elements created from scratch"
      ],
      benefits: [
        "Stand out from competitors with a one-of-a-kind website",
        "Perfect alignment with your brand identity and values",
        "Designs that resonate with your target audience",
        "Complete creative control over the final product"
      ]
    },
    {
      icon: Smartphone,
      title: "Mobile Responsive",
      description: "Perfect viewing experience across all devices and screen sizes",
      details: [
        "Responsive design that adapts to all screen sizes (mobile, tablet, desktop)",
        "Touch-friendly interfaces optimized for mobile interactions",
        "Fast loading times on mobile networks",
        "Progressive Web App (PWA) capabilities when needed",
        "Cross-browser compatibility (Chrome, Safari, Firefox, Edge)",
        "Tested on real devices to ensure perfect functionality"
      ],
      benefits: [
        "Reach users on any device they prefer",
        "Improved SEO rankings with mobile-first indexing",
        "Better user engagement and lower bounce rates",
        "Future-proof design that works on new devices"
      ]
    },
    {
      icon: Shield,
      title: "Modern UI/UX",
      description: "Cutting-edge user interface and experience design principles",
      details: [
        "Clean, contemporary design following latest web trends",
        "Intuitive navigation and user-friendly interfaces",
        "Smooth animations and micro-interactions for engagement",
        "Accessibility compliance (WCAG standards)",
        "Fast page load times and optimized performance",
        "Strategic placement of call-to-action elements"
      ],
      benefits: [
        "Enhanced user satisfaction and engagement",
        "Higher conversion rates and sales",
        "Professional appearance that builds trust",
        "Reduced user confusion and support requests"
      ]
    },
    {
      icon: DollarSign,
      title: "Affordable Pricing",
      description: "Competitive rates without compromising on quality",
      details: [
        "Transparent pricing with no hidden fees",
        "Flexible payment plans to suit your budget",
        "Package options for different business needs",
        "Free consultation and project estimate",
        "Cost-effective solutions using modern technologies",
        "Excellent value for money with premium features included"
      ],
      benefits: [
        "Professional website without breaking the bank",
        "Predictable costs for better budget planning",
        "More features for your investment compared to competitors",
        "Long-term savings with maintainable code"
      ]
    },
    {
      icon: Zap,
      title: "Fast Delivery",
      description: "Quick turnaround time to get your website live faster",
      details: [
        "Streamlined development process for rapid deployment",
        "Clear project timelines and milestone tracking",
        "Efficient workflow with modern development tools",
        "Regular progress updates throughout development",
        "Quick iteration cycles for feedback implementation",
        "Express launch options available for urgent projects"
      ],
      benefits: [
        "Get your business online quickly and start generating revenue",
        "Stay ahead of competitors with faster time-to-market",
        "Reduced opportunity costs with quicker project completion",
        "Start your digital marketing campaigns sooner"
      ]
    },
    {
      icon: HeadphonesIcon,
      title: "24/7 Support",
      description: "Dedicated support team ready to assist you anytime",
      details: [
        "Round-the-clock technical support via email and phone",
        "Quick response times to all inquiries",
        "Comprehensive documentation and training materials",
        "Regular maintenance and security updates",
        "Bug fixes and troubleshooting assistance",
        "Ongoing optimization and performance monitoring"
      ],
      benefits: [
        "Peace of mind knowing help is always available",
        "Minimal downtime with fast issue resolution",
        "Expert guidance whenever you need it",
        "Long-term partnership beyond project completion"
      ]
    }
  ];

  return (
    <>
      <section className="py-20 bg-[#0D0D0D]">
        <div className="max-w-[1440px] mx-auto px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Why Choose{" "}
              <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
                Us
              </span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] mx-auto mb-8"></div>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              We deliver excellence through innovation, quality, and dedication
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <button
                key={index}
                onClick={() => setSelectedFeature(feature)}
                className="bg-gradient-to-br from-[#0D0D0D] to-[#1a0d2e] border border-[#7B2CBF]/30 rounded-2xl p-8 hover:border-[#FF7A00]/50 transition-all hover:shadow-xl hover:shadow-[#7B2CBF]/20 group cursor-pointer text-left w-full"
              >
                <div className="w-14 h-14 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                <p className="text-gray-400 mb-3">{feature.description}</p>
                <span className="text-[#FF7A00] text-sm group-hover:text-[#7B2CBF] transition-colors">
                  Click for more details →
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <FeatureDetailModal 
        isOpen={selectedFeature !== null}
        onClose={() => setSelectedFeature(null)}
        feature={selectedFeature}
      />
    </>
  );
}