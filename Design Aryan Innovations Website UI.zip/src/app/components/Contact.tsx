import { Phone, Mail, MessageSquare } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-[#0D0D0D] to-[#1a0d2e]">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Start Your Website{" "}
            <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
              Today
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Get in touch with us to bring your vision to life
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <a
              href="tel:9494720041"
              className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-8 hover:border-[#FF7A00]/50 transition-all hover:shadow-xl hover:shadow-[#7B2CBF]/20 group flex flex-col items-center text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform flex-shrink-0 mb-4">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-1">Call us now</p>
                <p className="text-xl font-bold text-white">9494720041</p>
              </div>
            </a>

            <a
              href="mailto:info@aryaninnovations.com"
              className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-8 hover:border-[#FF7A00]/50 transition-all hover:shadow-xl hover:shadow-[#7B2CBF]/20 group flex flex-col items-center text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform flex-shrink-0 mb-4">
                <Mail className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-1">Email us at</p>
                <p className="text-lg font-bold text-white break-all">info@aryaninnovations.com</p>
              </div>
            </a>

            <a
              href="tel:7207267068"
              className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-8 hover:border-[#FF7A00]/50 transition-all hover:shadow-xl hover:shadow-[#7B2CBF]/20 group flex flex-col items-center text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-[#FF7A00] to-[#7B2CBF] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform flex-shrink-0 mb-4">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-1">Or reach us at</p>
                <p className="text-xl font-bold text-white">7207267068</p>
              </div>
            </a>
          </div>

          <div className="text-center">
            <a 
              href="mailto:info@aryaninnovations.com"
              className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white px-12 py-4 rounded-full hover:shadow-2xl hover:shadow-[#7B2CBF]/50 transition-all inline-flex items-center gap-3 text-lg group"
            >
              <MessageSquare className="w-6 h-6 group-hover:scale-110 transition-transform" />
              Contact Now
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}