import { X, LucideIcon } from "lucide-react";

interface FeatureDetail {
  title: string;
  icon: LucideIcon;
  description: string;
  details: string[];
  benefits: string[];
}

interface FeatureDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature: FeatureDetail | null;
}

export function FeatureDetailModal({ isOpen, onClose, feature }: FeatureDetailModalProps) {
  if (!isOpen || !feature) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      ></div>
      
      {/* Modal */}
      <div className="relative bg-gradient-to-b from-[#1a0d2e] to-[#0D0D0D] border border-[#7B2CBF]/30 rounded-2xl p-8 w-full max-w-2xl mx-4 shadow-2xl shadow-[#7B2CBF]/20 max-h-[90vh] overflow-y-auto">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors z-10"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <feature.icon className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">{feature.title}</h2>
          <p className="text-gray-300 text-lg">{feature.description}</p>
        </div>

        {/* Details Section */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <span className="w-1 h-6 bg-gradient-to-b from-[#7B2CBF] to-[#FF7A00]"></span>
            What We Offer
          </h3>
          <ul className="space-y-3">
            {feature.details.map((detail, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="w-2 h-2 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full mt-2 flex-shrink-0"></span>
                <span className="text-gray-300">{detail}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Benefits Section */}
        <div>
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <span className="w-1 h-6 bg-gradient-to-b from-[#FF7A00] to-[#7B2CBF]"></span>
            Key Benefits
          </h3>
          <div className="grid gap-3">
            {feature.benefits.map((benefit, index) => (
              <div key={index} className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/20 rounded-xl p-4">
                <p className="text-gray-300">{benefit}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-8 text-center">
          <a 
            href="#contact"
            onClick={onClose}
            className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white px-8 py-3 rounded-full hover:shadow-xl hover:shadow-[#7B2CBF]/50 transition-all inline-block"
          >
            Get Started Now
          </a>
        </div>
      </div>
    </div>
  );
}
