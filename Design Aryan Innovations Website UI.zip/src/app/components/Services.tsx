import { Briefcase, ShoppingCart, User, Laptop, ArrowRight } from "lucide-react";
import { useState } from "react";
import { ServiceDetailModal } from "./ServiceDetailModal";

export function Services() {
  const [selectedService, setSelectedService] = useState<number | null>(null);

  const services = [
    {
      icon: User,
      title: "Portfolio Website Development",
      description: "Showcase your work with stunning portfolio websites that leave a lasting impression.",
      gradient: "from-[#7B2CBF] to-[#FF7A00]",
      image: "https://images.unsplash.com/photo-1772272935464-2e90d8218987?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHBvcnRmb2xpbyUyMHdlYnNpdGUlMjBkZXNpZ258ZW58MXx8fHwxNzczNDg0MzczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      detailedDescription: "Stand out from the crowd with a custom portfolio website that showcases your creative work, projects, and achievements in the most compelling way. Perfect for designers, photographers, artists, developers, and creative professionals who want to make a lasting impression.",
      features: [
        "Custom design tailored to your creative style",
        "Interactive project galleries and showcases",
        "Responsive layouts for all devices",
        "Fast loading times and optimized images",
        "Contact forms and social media integration",
        "Blog section for sharing insights"
      ],
      benefits: [
        "Attract high-quality clients and opportunities",
        "Showcase your unique personality and style",
        "Easy to update and maintain",
        "Professional online presence 24/7",
        "SEO optimized for better visibility",
        "Mobile-friendly for on-the-go viewing"
      ],
      techStack: ["React", "Next.js", "Tailwind CSS", "Framer Motion", "TypeScript"],
      pricing: "₹799"
    },
    {
      icon: Briefcase,
      title: "Business Website Development",
      description: "Professional business websites designed to convert visitors into customers.",
      gradient: "from-[#FF7A00] to-[#7B2CBF]",
      image: "https://images.unsplash.com/photo-1603201667493-4c2696de0b1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdlYnNpdGUlMjBvZmZpY2V8ZW58MXx8fHwxNzczNTUyMTYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      detailedDescription: "Establish credibility and grow your business with a professional website that converts visitors into customers. We create modern, conversion-focused business websites that help you stand out in your industry and drive real results.",
      features: [
        "Professional and modern design",
        "Service/product showcase pages",
        "Lead generation and contact forms",
        "Customer testimonials and reviews section",
        "Google Maps integration",
        "Analytics and tracking setup"
      ],
      benefits: [
        "Build trust and credibility with potential clients",
        "Generate more leads and conversions",
        "Available to customers 24/7",
        "Competitive advantage in your market",
        "Cost-effective marketing platform",
        "Easy content management system"
      ],
      techStack: ["React", "WordPress", "Tailwind CSS", "Google Analytics", "SEO Tools"],
      pricing: "₹1,299"
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Website Development",
      description: "Full-featured online stores with secure payment integration and inventory management.",
      gradient: "from-[#7B2CBF] to-[#FF7A00]",
      image: "https://images.unsplash.com/photo-1763872038252-e6c4e0a11067?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbmxpbmUlMjBzaG9wcGluZyUyMGVjb21tZXJjZSUyMHN0b3JlfGVufDF8fHx8MTc3MzU1MjE2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      detailedDescription: "Take your business online with a powerful e-commerce platform that makes selling products easy and profitable. From product catalogs to secure checkout, we build everything you need to run a successful online store.",
      features: [
        "Secure payment gateway integration (Stripe, PayPal)",
        "Product catalog with categories and filters",
        "Shopping cart and checkout process",
        "Order management and tracking system",
        "Inventory management tools",
        "Customer account management"
      ],
      benefits: [
        "Sell products 24/7 without physical store",
        "Reach customers worldwide",
        "Automated order processing",
        "Detailed sales analytics and reports",
        "Scalable as your business grows",
        "Reduced operational costs"
      ],
      techStack: ["React", "Node.js", "Stripe API", "MongoDB", "Redux", "AWS"],
      pricing: "₹2,499"
    },
    {
      icon: Laptop,
      title: "Personal Brand Websites",
      description: "Build your personal brand with custom websites that reflect your unique identity.",
      gradient: "from-[#FF7A00] to-[#7B2CBF]",
      image: "https://images.unsplash.com/photo-1758273239330-9f32922ead06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb25hbCUyMGJyYW5kJTIwaW5mbHVlbmNlciUyMGNvbnRlbnR8ZW58MXx8fHwxNzczNTUyMTYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      detailedDescription: "Build a powerful personal brand with a website that tells your story and connects with your audience. Perfect for coaches, consultants, speakers, influencers, and professionals who want to establish themselves as industry leaders.",
      features: [
        "Personal branding and storytelling design",
        "About page highlighting your journey",
        "Services or speaking engagement pages",
        "Blog or content publishing platform",
        "Media kit and press section",
        "Newsletter signup and email integration"
      ],
      benefits: [
        "Establish yourself as an industry expert",
        "Build a loyal audience and community",
        "Monetize your expertise and knowledge",
        "Control your online narrative",
        "Professional hub for all your activities",
        "Grow your influence and reach"
      ],
      techStack: ["React", "Next.js", "Tailwind CSS", "Mailchimp", "CMS Integration"],
      pricing: "₹999"
    }
  ];

  return (
    <>
      <section id="services" className="py-20 bg-[#1a0d2e]">
        <div className="max-w-[1440px] mx-auto px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Our{" "}
              <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
                Services
              </span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] mx-auto mb-8"></div>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Comprehensive web solutions tailored to your unique needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div
                key={index}
                onClick={() => setSelectedService(index)}
                className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-6 hover:border-[#FF7A00]/50 transition-all hover:shadow-xl hover:shadow-[#7B2CBF]/20 hover:-translate-y-2 group cursor-pointer"
              >
                <div className={`w-16 h-16 bg-gradient-to-r ${service.gradient} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
                <p className="text-gray-400 mb-4">{service.description}</p>
                <div className="flex items-center gap-2 text-[#FF7A00] group-hover:gap-3 transition-all">
                  <span className="text-sm font-semibold">Learn More</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {selectedService !== null && (
        <ServiceDetailModal
          isOpen={selectedService !== null}
          onClose={() => setSelectedService(null)}
          service={services[selectedService]}
        />
      )}
    </>
  );
}