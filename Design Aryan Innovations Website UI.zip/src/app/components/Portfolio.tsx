import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ExternalLink } from "lucide-react";

export function Portfolio() {
  const portfolioItems = [
    {
      title: "Modern Portfolio",
      category: "Portfolio Website",
      image: "https://images.unsplash.com/photo-1762330463863-a6a399beb5ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3ZWJzaXRlJTIwcG9ydGZvbGlvJTIwc2hvd2Nhc2V8ZW58MXx8fHwxNzczNTA3MDcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      link: "https://likhitha-dev-showcase.base44.app"
    },
    {
      title: "Business Hub",
      category: "Business Website",
      image: "https://images.unsplash.com/photo-1637502877428-27e6553a8817?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHdlYnNpdGUlMjBkZXNpZ24lMjBsYXB0b3B8ZW58MXx8fHwxNzczNTA3MDcyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      link: "https://stripe.com"
    },
    {
      title: "E-Store Pro",
      category: "E-commerce",
      image: "https://images.unsplash.com/photo-1461151150871-ca0a4bff5307?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjB3ZWJzaXRlJTIwdGFibGV0JTIwbW9ja3VwfGVufDF8fHx8MTc3MzUwNzA3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      link: "https://demo.vercel.store"
    },
    {
      title: "Personal Brand",
      category: "Brand Website",
      image: "https://images.unsplash.com/photo-1707836868495-3307d371aba4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBwaG9uZSUyMHdlYnNpdGUlMjBtb2NrdXB8ZW58MXx8fHwxNzczNTA3MDczfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      link: "https://bruno-simon.com"
    }
  ];

  return (
    <section id="portfolio" className="py-20 bg-gradient-to-b from-[#1a0d2e] to-[#0D0D0D]">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our{" "}
            <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
              Portfolio
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Explore our latest website projects across different platforms
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {portfolioItems.map((item, index) => (
            <a
              key={index}
              href={item.link}
              target="_blank"
              rel="noopener noreferrer"
              className={`group relative bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl overflow-hidden hover:border-[#FF7A00]/50 transition-all hover:shadow-2xl hover:shadow-[#7B2CBF]/30 block ${!item.link ? 'pointer-events-none' : 'cursor-pointer'}`}
            >
              <div className="relative h-80 overflow-hidden">
                <ImageWithFallback
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-transparent opacity-60"></div>
              </div>
              
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[#FF7A00] text-sm mb-1">{item.category}</p>
                    <h3 className="text-2xl font-bold text-white">{item.title}</h3>
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ExternalLink className="w-5 h-5 text-white" />
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}