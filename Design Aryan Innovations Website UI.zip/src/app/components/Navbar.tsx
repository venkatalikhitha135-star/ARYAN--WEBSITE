import { Logo } from "./Logo";
import { LogIn } from "lucide-react";
import { useState } from "react";
import { SignInModal } from "./SignInModal";

export function Navbar() {
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0D0D0D]/80 backdrop-blur-lg border-b border-[#7B2CBF]/20">
        <div className="max-w-[1440px] mx-auto px-8 py-4 flex items-center justify-between">
          <Logo />
          
          <div className="flex items-center gap-8">
            <a href="#home" className="text-white hover:text-[#7B2CBF] transition-colors">
              Home
            </a>
            <a href="#about" className="text-white hover:text-[#7B2CBF] transition-colors">
              About
            </a>
            <a href="#services" className="text-white hover:text-[#7B2CBF] transition-colors">
              Services
            </a>
            <a href="#portfolio" className="text-white hover:text-[#7B2CBF] transition-colors">
              Portfolio
            </a>
            <a href="#contact" className="text-white hover:text-[#7B2CBF] transition-colors">
              Contact
            </a>
            <button 
              onClick={() => setIsSignInOpen(true)}
              className="text-white hover:text-[#7B2CBF] transition-colors flex items-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Sign In
            </button>
            <button className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white px-6 py-2 rounded-full hover:shadow-lg hover:shadow-[#7B2CBF]/50 transition-all">
              Get Website
            </button>
          </div>
        </div>
      </nav>

      <SignInModal isOpen={isSignInOpen} onClose={() => setIsSignInOpen(false)} />
    </>
  );
}