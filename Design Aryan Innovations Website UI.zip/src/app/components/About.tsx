import { Target, Users, Zap } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-[#0D0D0D] to-[#1a0d2e]">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            About{" "}
            <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
              Aryan Innovations
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] mx-auto mb-8"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <p className="text-xl text-gray-300 text-center leading-relaxed mb-12">
            Aryan Innovations is a leading digital solutions company specializing in creating custom websites 
            for individuals, startups, and businesses. We help our clients establish a strong online presence 
            through modern, responsive, and visually stunning web platforms that perfectly match their vision 
            and business goals.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-6 text-center hover:border-[#FF7A00]/50 transition-all group">
              <div className="w-16 h-16 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Mission Driven</h3>
              <p className="text-gray-400">Empowering businesses with exceptional digital solutions</p>
            </div>
            
            <div className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-6 text-center hover:border-[#FF7A00]/50 transition-all group">
              <div className="w-16 h-16 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Client Focused</h3>
              <p className="text-gray-400">Your vision is our priority in every project</p>
            </div>
            
            <div className="bg-[#0D0D0D]/50 border border-[#7B2CBF]/30 rounded-2xl p-6 text-center hover:border-[#FF7A00]/50 transition-all group">
              <div className="w-16 h-16 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Innovation First</h3>
              <p className="text-gray-400">Cutting-edge technology for modern solutions</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
