import { ArrowRight, Sparkles } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useState } from "react";
import { CompanyPortfolioModal } from "./CompanyPortfolioModal";

export function Hero() {
  const [isPortfolioOpen, setIsPortfolioOpen] = useState(false);

  return (
    <>
      <section id="home" className="min-h-screen flex items-center pt-20 bg-[#0D0D0D]">
        <div className="max-w-[1440px] mx-auto px-8 py-20 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#7B2CBF]/10 border border-[#7B2CBF]/30 rounded-full">
              <Sparkles className="w-4 h-4 text-[#FF7A00]" />
              <span className="text-sm text-white">Digital Solutions for Modern Businesses</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-white leading-tight">
              Build Your Dream Website with{" "}
              <span className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
                Aryan Innovations
              </span>
            </h1>
            
            <p className="text-xl text-gray-300">
              Custom portfolio and business websites designed to match your vision.
            </p>
            
            <div className="flex gap-4">
              <a
                href="#contact"
                className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white px-8 py-4 rounded-full hover:shadow-xl hover:shadow-[#7B2CBF]/50 transition-all flex items-center gap-2 group"
              >
                Get Your Website
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <button
                onClick={() => setIsPortfolioOpen(true)}
                className="border-2 border-[#7B2CBF] text-white px-8 py-4 rounded-full hover:bg-[#7B2CBF]/10 transition-all"
              >
                View Portfolio
              </button>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] blur-3xl opacity-20"></div>
            <div className="relative rounded-2xl overflow-hidden border border-[#7B2CBF]/30 shadow-2xl shadow-[#7B2CBF]/20">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1537183673931-f890242dbaef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjB3ZWJzaXRlJTIwZGVzaWduJTIwbW9ja3VwJTIwZGFya3xlbnwxfHx8fDE3NzM0NDI4OTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Website mockup"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <CompanyPortfolioModal 
        isOpen={isPortfolioOpen}
        onClose={() => setIsPortfolioOpen(false)}
      />
    </>
  );
}