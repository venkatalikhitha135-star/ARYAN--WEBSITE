import { Logo } from "./Logo";
import { Facebook, Twitter, Instagram, Linkedin, Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[#0D0D0D] border-t border-[#7B2CBF]/20 py-12">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-8">
          <Logo />
          
          <div className="flex gap-8">
            <a href="#home" className="text-gray-400 hover:text-[#7B2CBF] transition-colors">
              Home
            </a>
            <a href="#services" className="text-gray-400 hover:text-[#7B2CBF] transition-colors">
              Services
            </a>
            <a href="#portfolio" className="text-gray-400 hover:text-[#7B2CBF] transition-colors">
              Portfolio
            </a>
            <a href="#contact" className="text-gray-400 hover:text-[#7B2CBF] transition-colors">
              Contact
            </a>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-8 border-t border-[#7B2CBF]/20">
          <p className="text-gray-400 text-sm">© 2026 Aryan Innovations. All rights reserved.</p>
          
          <div className="flex gap-4">
            <a
              href="#"
              className="w-10 h-10 bg-[#7B2CBF]/10 border border-[#7B2CBF]/30 rounded-full flex items-center justify-center hover:bg-[#7B2CBF]/20 hover:border-[#FF7A00]/50 transition-all"
            >
              <Facebook className="w-5 h-5 text-gray-400" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-[#7B2CBF]/10 border border-[#7B2CBF]/30 rounded-full flex items-center justify-center hover:bg-[#7B2CBF]/20 hover:border-[#FF7A00]/50 transition-all"
            >
              <Twitter className="w-5 h-5 text-gray-400" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-[#7B2CBF]/10 border border-[#7B2CBF]/30 rounded-full flex items-center justify-center hover:bg-[#7B2CBF]/20 hover:border-[#FF7A00]/50 transition-all"
            >
              <Instagram className="w-5 h-5 text-gray-400" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-[#7B2CBF]/10 border border-[#7B2CBF]/30 rounded-full flex items-center justify-center hover:bg-[#7B2CBF]/20 hover:border-[#FF7A00]/50 transition-all"
            >
              <Linkedin className="w-5 h-5 text-gray-400" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-[#7B2CBF]/10 border border-[#7B2CBF]/30 rounded-full flex items-center justify-center hover:bg-[#7B2CBF]/20 hover:border-[#FF7A00]/50 transition-all"
            >
              <Github className="w-5 h-5 text-gray-400" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
