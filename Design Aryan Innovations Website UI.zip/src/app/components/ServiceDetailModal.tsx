import { X, Check, ArrowRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface ServiceDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  service: {
    title: string;
    description: string;
    image: string;
    detailedDescription: string;
    features: string[];
    benefits: string[];
    techStack: string[];
    pricing: string;
  };
}

export function ServiceDetailModal({ isOpen, onClose, service }: ServiceDetailModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/90 backdrop-blur-sm"
        onClick={onClose}
      ></div>
      
      {/* Modal */}
      <div className="relative min-h-screen flex items-start justify-center p-4 py-8">
        <div className="relative bg-gradient-to-b from-[#1a0d2e] to-[#0D0D0D] border border-[#7B2CBF]/30 rounded-2xl w-full max-w-4xl shadow-2xl shadow-[#7B2CBF]/20">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-6 right-6 text-gray-400 hover:text-white transition-colors z-10 bg-[#0D0D0D]/80 rounded-full p-2"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Hero Image */}
          <div className="relative h-64 overflow-hidden rounded-t-2xl">
            <ImageWithFallback
              src={service.image}
              alt={service.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-transparent to-transparent"></div>
            <div className="absolute bottom-6 left-8 right-8">
              <h2 className="text-3xl md:text-4xl font-bold text-white">
                {service.title}
              </h2>
            </div>
          </div>

          <div className="p-8">
            {/* Description */}
            <p className="text-lg text-gray-300 mb-8">
              {service.detailedDescription}
            </p>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              {/* Features */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="w-1 h-6 bg-gradient-to-b from-[#7B2CBF] to-[#FF7A00]"></span>
                  Key Features
                </h3>
                <ul className="space-y-3">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Benefits */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <span className="w-1 h-6 bg-gradient-to-b from-[#FF7A00] to-[#7B2CBF]"></span>
                  Benefits
                </h3>
                <ul className="space-y-3">
                  {service.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-[#7B2CBF] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Tech Stack */}
            <div className="mb-8">
              <h3 className="text-xl font-bold text-white mb-4">Technologies We Use</h3>
              <div className="flex flex-wrap gap-3">
                {service.techStack.map((tech, index) => (
                  <span 
                    key={index}
                    className="bg-gradient-to-r from-[#7B2CBF]/20 to-[#FF7A00]/20 border border-[#7B2CBF]/30 text-white px-4 py-2 rounded-full text-sm"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Pricing */}
            <div className="bg-gradient-to-r from-[#7B2CBF]/10 to-[#FF7A00]/10 border border-[#7B2CBF]/30 rounded-xl p-6 mb-8">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                  <p className="text-gray-400 mb-1">Starting From</p>
                  <p className="text-3xl font-bold bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] bg-clip-text text-transparent">
                    {service.pricing}
                  </p>
                </div>
                <a 
                  href="#contact"
                  onClick={onClose}
                  className="bg-gradient-to-r from-[#7B2CBF] to-[#FF7A00] text-white px-8 py-3 rounded-full hover:shadow-xl hover:shadow-[#7B2CBF]/50 transition-all inline-flex items-center gap-2 group"
                >
                  Get Started
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>

            {/* CTA */}
            <div className="text-center">
              <p className="text-gray-400 mb-4">
                Ready to bring your vision to life? Contact us for a free consultation!
              </p>
              <button
                onClick={onClose}
                className="border-2 border-[#7B2CBF] text-white px-8 py-3 rounded-full hover:bg-[#7B2CBF]/10 transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
