
  # Design Aryan Innovations Website UI

  This is a code bundle for Design Aryan Innovations Website UI. The original project is available at https://www.figma.com/design/qZ1GmxxActD0pGirDc2jWK/Design-Aryan-Innovations-Website-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  